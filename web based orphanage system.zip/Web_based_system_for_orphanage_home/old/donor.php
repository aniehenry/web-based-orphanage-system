<?php
extract($_POST);
session_start();
include("dbconnect.php");
if(isset($_POST['Submit']))
{
  $username=$_REQUEST['username'];
  $password=$_REQUEST['password'];
   if($conn->connect_error)
   {
     die("Connection failed: " . $conn->connect_error);
   }
   else
   {
     $qry="select * from donor_details where email='$username' and password='$password'";
     $result = mysqli_query($conn,$qry);
	$var=mysqli_num_rows($result);
	  if($var>0)
	  {
	  ?>
	  <script language="javascript">
	  alert("login Success");
	  window.location.href="donor_home.php";
	  </script>
	  <?php
	  
      }
	
	else
	 {
	 ?>
	 <script language="javascript">
	 alert("Invalid user");
	   window.location.href="donor.php";
	 </script>
	 <?php
	 
	 }
   }
  $conn->close();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
  <link rel="stylesheet" href="style.css">
<style type="text/css">
<!--
.style1 {
	font-family: "Times New Roman", Times, serif;
	font-size: 36px;
	font-weight: bold;
	font-style: italic;
	color: #CC0033;
}
.style2 {	font-family: "Times New Roman", Times, serif;
	font-size: 26px;
	font-weight: bold;
	font-style: italic;
	color: #CC0033;
}
-->
</style>
<p style="background-image: url('1.jpeg');">


<body background="bck.jpg">
<h4 align="center" class="style1">WEB CLOUD ORPHANAGE HOME</h4>
<table width="90" height="30" align="center" class="frame_alighn">
  <tr>
    <td><p align="center" class="style2"><a href="admin.php">Admin</a></p></td>
    <td><p align="center" class="style2"><a href="trust.php">Trust</a></p></td>
    <td><p align="center" class="style2"><a href="donor.php">Donor</a> </p></td>
  </tr>
</table>
<p align="center" class="style1">&nbsp;</p>
<p align="center" class="style1">DONOR LOGIN </p>
<form id="form1" name="form1" method="post" action="">
  <table width="200" border="0" align="center">
    <tr>
      <td><p>Email</p></td>
      <td><label>
        <input name="username" type="text" id="username" />
      </label></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><label>
        <input name="password" type="password" id="password" />
      </label></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><label>
        <input type="submit" name="Submit" value="Submit" />
      </label></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><a href="donor_register.php">New User </a></td>
    </tr>
  </table>
</form>
<p align="center" class="style1">&nbsp;</p>
</body>
</html>
