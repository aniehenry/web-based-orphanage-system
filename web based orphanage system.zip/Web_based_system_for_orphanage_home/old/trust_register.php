<?php
extract($_POST);
session_start();
include("dbconnect.php");
 if(isset($Submit))
{
 
$trust_name=$_REQUEST['trust_name'];
$address=$_REQUEST['address'];
$email=$_REQUEST['email'];
$contact=$_REQUEST['contact'];
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
 
 $sql = "SELECT id FROM trust_details order by id ASC";

 $sid=0;
  $result = $conn->query($sql);
  while($row = $result->fetch_assoc()) 
  {
       $sid=$row['id'];
  }
    $sid=$sid+1;
    
   $qrys1="insert into trust_details values($sid,'$trust_name','$address','$email','$contact','$username','$password','0','0')";
  if ($conn->query($qrys1) === TRUE) {
  ?>
<script language="javascript" type="text/javascript">
alert("Registration Successfully");
window.location.href="trust.php";
</script>
<?php   
 }
 else
{
    
?>
<script language="javascript" type="text/javascript">
alert("Failed");
 
</script>
<?php 
}
$conn->close();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
  <link rel="stylesheet" href="style.css">
<style type="text/css">
<!--
.style1 {
	font-family: "Times New Roman", Times, serif;
	font-size: 36px;
	font-weight: bold;
	font-style: italic;
	color: #CC0033;
}
.style2 {	font-family: "Times New Roman", Times, serif;
	font-size: 26px;
	font-weight: bold;
	font-style: italic;
	color: #CC0033;
}
-->
</style>
<p style="background-image: url('1.jpeg');">


<body background="bck.jpg">
<h4 align="center" class="style1">WEB CLOUD ORPHANAGE HOME</h4>
<table width="90" height="30" align="center" class="frame_alighn">
  <tr>
    <td><p align="center" class="style2"><a href="admin.php">Admin</a></p></td>
    <td><p align="center" class="style2"><a href="trust.php">Trust</a></p></td>
    <td><p align="center" class="style2"><a href="donor.php">Donor</a> </p></td>
  </tr>
</table>
<p align="center" class="style1">&nbsp;</p>
<p align="center" class="style1">Trust Register </p>
<form id="form1" name="form1" method="post" action="">
  <table width="285" border="0" align="center">
    <tr>
      <td>Trust Name </td>
      <td><input name="trust_name" type="text" id="trust_name" required="" /></td>
    </tr>
    <tr>
      <td>Address</td>
      <td><input name="address" type="text" id="address" required="" /></td>
    </tr>
    <tr>
      <td>Email</td>
      <td><input name="email" type="text" id="email" required="" /></td>
    </tr>
    <tr>
      <td>Contact</td>
      <td><input name="contact" type="text" id="contact" required="" /></td>
    </tr>
    <tr>
      <td><p>Username</p></td>
      <td><label>
        <input name="username" type="text" id="username" required="" />
      </label></td>
    </tr>
    <tr>
      <td>Password</td>
      <td><label>
        <input name="password" type="password" id="password" />
      </label></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><label>
        <input type="submit" name="Submit" value="Submit" />
      </label></td>
    </tr>
  </table>
</form>
<p align="center" class="style1">&nbsp;</p>
</body>
</html>
