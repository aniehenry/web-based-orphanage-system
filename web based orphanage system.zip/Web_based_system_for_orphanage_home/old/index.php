<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<style type="text/css">
<!--
.style1 {
	font-family: "Times New Roman", Times, serif;
	font-size: 36px;
	font-weight: bold;
	font-style: italic;
	color: #CC0033;
}
-->
</style>
<p style="background-image: url('1.jpeg');">


<body background="bck.jpg">
<h4 align="center" class="style1">WEB CLOUD ORPHANAGE HOME</h4>
<p align="center" class="style1"><img src="2.jpg" width="360" height="360" /></p>
<table width="90" height="75" align="center">
 
 
  <td><p align="center" class="style1"><a href="admin.php">Admin</a></p></td>
</tr>
<tr>
  <td><p align="center" class="style1"><a href="trust.php">Trust</a></p></td>
</tr>
<tr>
  <td><p align="center" class="style1"><a href="donor.php">Donor</a> </p></td>
</tr>
</table>

</body>
</html>
