      <?php
$servername = "Localhost";
$username = "root";
$password = "";
$dbname = "php_orphanage_management";

$conn = new mysqli($servername, $username, $password, $dbname);
?>